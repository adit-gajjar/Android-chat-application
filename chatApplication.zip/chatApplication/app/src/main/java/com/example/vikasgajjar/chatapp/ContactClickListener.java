package com.example.vikasgajjar.chatapp;

import android.view.View;

/**
 * Created by vikasgajjar on 2018-08-21.
 */

public interface ContactClickListener {
    public void onClick(View view, int position);
}
